<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
</head>
<body>
  <?php
session_start();
if(isset($_SESSION['uname']))
{
  Echo "Name: ".htmlspecialchars($_SESSION['uname']);
  echo"<br>";
}

if(isset($_SESSION['id']))
{
  Echo "ID: ".htmlspecialchars($_SESSION['id']);
  echo"<br>";
}
if(isset($_SESSION['gender']))
{
  Echo "Gender: ".htmlspecialchars($_SESSION['gender']);
  echo"<br>";
}
if(isset($_SESSION['gmail']))
{
  Echo "Gmail: ".htmlspecialchars($_SESSION['gmail']);
  echo"<br>";
}
if(isset($_SESSION['number']))
{
  Echo "Phone Number: ".htmlspecialchars($_SESSION['number']);
  echo"<br>";
}
if(isset($_SESSION['dob']))
{
  Echo "Date of Birth: ".htmlspecialchars($_SESSION['dob']);
  echo"<br>";
}
if(isset($_SESSION['language']))
{
  Echo "Favourite language: ".htmlspecialchars($_SESSION['language']);
  echo"<br>";
}

else{
  echo"Nothing found";
}



?>
<form  action="formvalidation.php">
<input type="submit" value="Home">
</form>
</body>
</html>